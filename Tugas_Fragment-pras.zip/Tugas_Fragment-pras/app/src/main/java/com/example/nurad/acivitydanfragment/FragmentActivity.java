package com.example.nurad.acivitydanfragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class FragmentActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
    }

    public void fragmenttt(View view) {
        load_fragment(new Fragment1());
    }

    public void fragment2(View view) {
        load_fragment(new Fragment2());
    }
private void load_fragment(Fragment fragment) {
    FragmentManager frgmnt = getSupportFragmentManager();
    FragmentTransaction frgmnt2 = frgmnt.beginTransaction();
    frgmnt2.replace(R.id.frame_fragment, fragment);
    frgmnt2.commit();

}

}
